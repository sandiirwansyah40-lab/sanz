import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "9999"))

DEVS = list(map(int, os.getenv("DEVS", "7230983425").split()))

API_ID = int(os.getenv("API_ID", "15384433"))

API_HASH = os.getenv("API_HASH", "a3bee15207d04e1470160be3ea7bdc32")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8869235349:AAEC2B39N5mOoSxTbSBf--ta_DJXcSMv74Q")

OWNER_ID = int(os.getenv("OWNER_ID", "7230983425"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002273991891").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://sanz444:sanz444@cluster0.re6l92c.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002273991891"))